package cc.silk.event.types;

public enum TransferOrder {
    SEND, RECEIVE
}