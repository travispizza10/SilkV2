package cc.silk.event.impl.player;

import cc.silk.event.types.Event;

public class TickEvent implements Event {
}
