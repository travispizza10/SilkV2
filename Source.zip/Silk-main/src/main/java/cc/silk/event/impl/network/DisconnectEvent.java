package cc.silk.event.impl.network;


import cc.silk.event.types.Event;

public class DisconnectEvent implements Event {
}