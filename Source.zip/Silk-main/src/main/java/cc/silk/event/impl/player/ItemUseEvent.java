package cc.silk.event.impl.player;

import cc.silk.event.types.CancellableEvent;

public class ItemUseEvent extends CancellableEvent {
}
