package cc.silk.event.types;

public interface Event {
}