package cc.silk.module.modules.client;

import cc.silk.module.Category;
import cc.silk.module.Module;

public class Secret extends Module {

    public Secret() {
        super("Secret", "https://discord.gg/cysense", 0, Category.CLIENT);
    }
}
