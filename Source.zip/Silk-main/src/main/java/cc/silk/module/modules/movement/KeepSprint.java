package cc.silk.module.modules.movement;

import cc.silk.module.Category;
import cc.silk.module.Module;

public class KeepSprint extends Module {
    public KeepSprint() {
        super("Keep Sprint", "Cancels the motion reduce when you attack", -1, Category.MOVEMENT);
    }
}
